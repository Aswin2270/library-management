public class Module2 {



    public void Computerscience(){
        System.out.println("");
        String csc[]={"Principles of Management & Engineering Economics"," Advanced Computer Programming"," Digital Electronics","Data Structure Lab "};


        System.out.println("The books available in Computer Science department are as follow:");
        for (int i=0; i< csc.length;i++){

            System.out.println(csc[i]);

        }


    }


    public void Mechanicalengineering(){
        System.out.println("");
        String mech[]={"Introduction to Material Science and Engineering","Introduction to Bioscience and Technology","Fluid Mechanics","Workshop Processes"};

        System.out.println("The books available in Mechanical Engineering department are as follow:");

        for(int j=0; j<mech.length;j++){

            System.out.println(mech[j]);
        }

    }



    public void ArtificialIntelligenceandDataScience(){

        System.out.println("");
        String AIandDS[]={"Object oriented programming","Fundamental of Data Science","Discrete Mathematics","Design analysis of algorithm","Introduction of operating system"};

        System.out.println("The books available in Artificial Intelligence and DataScience department are as follow:");
        
        for (int k=0;k<AIandDS.length;k++){

            System.out.println(AIandDS[k]);
        }

    }


}